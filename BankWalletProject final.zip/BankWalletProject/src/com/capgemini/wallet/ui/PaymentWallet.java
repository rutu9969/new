package com.capgemini.wallet.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.exception.WalletException;
import com.capgemini.wallet.service.WalletServices;

public class PaymentWallet {

	public static void main(String[] args) throws IOException {
		// declaring the variables

		String option;
		String name;
		String age;
		String address;
		String email;
		String option1;
		double amount;

		// creating objects of the classes

		WalletServices vud = new WalletServices();

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);

		while (true) {
			// method for registration
			while (true) {
				System.out
						.println("Welcome to Your Finance : \n1.Register For New Account \n2.Login \n3.Exit");
				option = br.readLine();
				boolean isValid = vud.validateChoice(option);
				if (isValid)
					break;
				else
					System.out.println("The choice should be 1 or 2 :");
			}
			switch (option) {

			case "1":
				// name
				while (true) {
					System.out.println("Please Enter Your Name : ");
					name = br.readLine();
					boolean isValid = vud.validateUserName(name);
					if (isValid)
						break;
					else
						System.out
								.println("*The name should contain 1st letter capital*");

				}
				// age
				while (true) {

					System.out.println("Enter Your Age :");
					age = br.readLine();
					boolean isValid = vud.validateUserAge(age);
					if (isValid)
						break;
					else
						System.out
								.println("*You should be above 22 years for processing loan*");
				}

				// Address
				while (true) {
					System.out.println("Enter Your Address : ");
					address = br.readLine();
					boolean isValid = vud.validateUserAddress(address);
					if (isValid)
						break;
					else
						System.out.println("This cannot be blank ");

				}

				// Email

				while (true) {
					System.out.println("Enter Your Email : ");
					email = br.readLine();
					boolean isValid = vud.validateUserEmailAddress(email);
					if (isValid)
						break;
					else
						System.out
								.println("The email format is incorrect please re-enter with atleast one @ and .com");
				}

				// display map details
				try {
					vud.createUser(name, age, address, email);
					vud.storeIntoMap();
				} catch (WalletException e) {
					System.out.println(e);
				}
				
				break;
			case "2":
				System.out.println("Please Enter your 3 digit account number");
				int Accno = sc.nextInt();
				try {
					vud.validateAccountNo(Accno);
					while (true) {
						System.out
								.println("What service would you like to opt today :");
						System.out.println("1.Show Balance");
						System.out.println("2.Deposit Money");
						System.out.println("3.Withdraw Money");
						System.out.println("4.Fund Transfer");
						System.out.println("5.Print Transactions");
						System.out.println("6.Exit");
						option1 = sc.next();
						int choice = Integer.parseInt(option1);
						switch (choice) {
						case 1:
							System.out.println(vud.showBalance(Accno));
							break;
						case 2:
							System.out
									.println("Please enter the amount you wish to deposit :");
							amount = sc.nextDouble();
							vud.depositMoney(amount,Accno);
							break;

						case 3:

							System.out
									.println("Please enter the amount you wish to withdraw :");
							amount = sc.nextDouble();
							vud.withdrawMoney(amount,Accno);
							break;
						case 4:
							System.out
									.println("Please enter the Account number of the receiptent :");
							int accno = sc.nextInt();
							System.out.println("Enter the Amount");
							amount = sc.nextDouble();
							vud.fundTransfer(amount);
							break;

						case 5:
							System.out
									.println("--------Transactions History-------");
							vud.printTransaction(Accno);
							break;
						case 6:
							System.out
									.println("Thanks for choosing Your Finance");
							System.exit(0);
							break;

						default:
							System.out
									.println("Invalid choice please from the given choice ");
							break;
						}

					}
				} catch (WalletException e) {
					System.out.println(e);
				}

				break;
			case "3": {
				System.out.println("Thanks for your intrest");
				break;

			}
			}
		}
	}
}