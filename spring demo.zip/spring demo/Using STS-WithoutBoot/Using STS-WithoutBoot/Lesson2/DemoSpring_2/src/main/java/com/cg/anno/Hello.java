package com.cg.anno;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("hi")
public class Hello {
	private String greeting;
	public Hello() {
		
	}
		public Hello(String greeting) {
			this.greeting=greeting;
			
		}
		public String getGreeting() {
			return greeting;
		}
		@Value("hello spring")
		public void setGreeting(String greeting) {
			this.greeting = greeting;
		}
	

}
