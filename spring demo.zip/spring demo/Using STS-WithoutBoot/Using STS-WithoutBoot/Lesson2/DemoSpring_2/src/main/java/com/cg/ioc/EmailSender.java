package com.cg.ioc;

public class EmailSender implements Sender{
	public EmailSender() {
		System.out.println("Email sender is ready");
	}
	public void send(String to,String msg) {
		System.out.println("Email: "+msg+"send to "+to);
	}

}
