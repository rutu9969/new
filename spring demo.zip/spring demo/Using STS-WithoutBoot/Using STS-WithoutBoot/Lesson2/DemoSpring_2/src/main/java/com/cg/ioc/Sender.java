package com.cg.ioc;

public interface Sender {
	void send(String to,String msg);
		
	

}
