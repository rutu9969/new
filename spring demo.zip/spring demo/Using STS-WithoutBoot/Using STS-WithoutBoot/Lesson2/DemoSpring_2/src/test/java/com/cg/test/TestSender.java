package com.cg.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.anno.Producer;

public class TestSender {
	@Test
	public void testProcess() {
		//ApplicationContext ctx=new ClassPathXmlApplicationContext("sender.xml");
		ApplicationContext ctx=new ClassPathXmlApplicationContext("annotated.xml");
		Producer p=(Producer)ctx.getBean("prod");
		p.process("sms", "7038262097", "Hello");
		p.process("mail", "rutuja@gmail.com", "Hii");
		p.process("wap", "7038262097", "namaskar");

	}

}
