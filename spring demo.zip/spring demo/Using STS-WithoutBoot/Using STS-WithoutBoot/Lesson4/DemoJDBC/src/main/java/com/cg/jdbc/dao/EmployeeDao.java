package com.cg.jdbc.dao;

import java.util.List;

import com.cg.jdbc.bean.Employee;

public interface EmployeeDao {
	public int getCount();
	public String getEmployeeName(int eid);
	public int insertRec(int eid,String enm,double esl);
	public int updateRec(int eid,String enm,double esl);
	public List getAll();
	public Employee getEmpByEid(int eid) ;
	public List<Employee> getEmployeeList() ;
}
